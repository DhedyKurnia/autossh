#!/bin/bash

clear
neofetch
cat /root/log-install.txt
echo ""
Premium VPS Script

Supports: OpenSSH, OpenSSH Websocket, OpenVPN, Wireguard, L2TP, PPTP, SSTP, SSR, Shadowsocks OBFS, VMESS, VLESS, Trojan,

To install

apt update && apt install -y wget && wget https://raw.githubusercontent.com/Gl33ch3r/autoscript/main/setup.sh && chmod +x setup.sh && ./setup.sh
